// butt 2 pole 10 to 20 sec
#ifndef _BOOST_FILTER_H_
#define _BOOST_FILTER_H_

// boost_biquads

#define BOOST_BIQUADS_SIZE 2
extern float boost_biquads[BOOST_BIQUADS_SIZE][6];
// boost_biquads gain

extern float boost_biquads_g ;


#endif

