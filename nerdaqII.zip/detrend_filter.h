#ifndef _DETREND_FILTER_H_
#define _DETREND_FILTER_H_

// detrend_biquads

#define DETREND_BIQUADS_SIZE 1
extern float detrend_biquads[DETREND_BIQUADS_SIZE][6];
// detrend_biquads gain

extern float detrend_biquads_g ;


#endif

