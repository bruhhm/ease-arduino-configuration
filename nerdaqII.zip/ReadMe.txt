Tue Aug 21 09:54:52 EDT 2012

Files:
        MemoryFree.cpp          compute free memory
        MemoryFree.h
        biquad.c                general support for biquad filters
        biquad.h
        boost_filter.cpp        long-period boost filter parameters
        boost_filter.h
        detrend_filter.cpp      high-pass detrend filter parameters
        detrend_filter.h
        filters                 directory of filter design files
        nerdaqII.org            emacs org file for this project
        nerdaqII.pde            current multi-filter nerdaq sketch
        nerdaqI/nerdaqI.pde     original nerdaq sketch

